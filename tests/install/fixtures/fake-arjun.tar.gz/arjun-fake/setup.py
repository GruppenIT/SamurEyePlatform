from setuptools import setup, find_packages
setup(name='arjun', version='0.0.0-fake', packages=find_packages(), entry_points={'console_scripts':['arjun=arjun.cli:main']})
